export const mainUrl = "http://kuybaca-staging.herokuapp.com";
