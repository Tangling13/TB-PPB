import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AuthConstants } from "../../../config/auth-constants";
import { AuthService } from "./../../services/auth.service";
import { StorageService } from "./../../services/storage.service";
import { UtilsService } from "./../../services/utils.service";

@Component({
  selector: "app-signin",
  templateUrl: "./signin.page.html",
  styleUrls: ["./signin.page.scss"],
})
export class SigninPage implements OnInit {
  postData = {
    email: "",
    password: "",
  };

  constructor(
    private router: Router,
    private authService: AuthService,
    private storageService: StorageService,
    private toastService: UtilsService
  ) {}

  ngOnInit() {}

  validateInputs() {
    let email = this.postData.email.trim();
    let password = this.postData.password.trim();
    return (
      this.postData.email &&
      this.postData.password &&
      email.length > 0 &&
      password.length > 0
    );
  }

  signin() {
    if (this.validateInputs()) {
      this.authService.login(this.postData).subscribe(
        (res: any) => {
          if (res.token) {
            this.storageService.store(AuthConstants.AUTH, res).then((res) => {
              this.router.navigate(["home/dashboard"]);
            });
          } else {
            this.toastService.showToast("Incorrect email or password.");
            console.log("ada yang error");
          }
        },
        (error: any) => {
          this.toastService.showToast("Network Issue.");
          console.log("ada yang error2");
        }
      );
    } else {
      console.log("Please enter email or password");
    }
  }
}
