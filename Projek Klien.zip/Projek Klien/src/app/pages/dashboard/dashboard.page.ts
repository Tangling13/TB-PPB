import { Component, OnInit } from "@angular/core";
import { BooksService } from "../../services/books.service";
import { AuthService } from "src/app/services/auth.service";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.page.html",
  styleUrls: ["./dashboard.page.scss"],
})
export class DashboardPage implements OnInit {
  listBooks: any = [];
  public authUser: any;

  constructor(private bookService: BooksService, private auth: AuthService) {}

  getAllBooks() {
    this.bookService.getAllBooks().subscribe(
      (response) => {
        this.listBooks = response;
      },
      (err) => {
        this.listBooks = [];
      }
    );
  }

  ionViewWillEnter() {
    this.getAllBooks();
  }

  doRefresh(event) {
    this.getAllBooks();
    setTimeout(() => {
      event.target.complete();
    }, 1000);
  }

  ngOnInit() {
    this.auth.userData$.subscribe((res: any) => {
      this.authUser = res;
    });
  }
}
